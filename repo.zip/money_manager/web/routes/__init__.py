from money_manager.web import auth
from money_manager.web.routes import net_explanation
from money_manager.web.routes.accounts import accounts, currencies, internal_transfers
from money_manager.web.routes.assets import investments
from money_manager.web.routes.core import analysis, dashboard, transactions, yearly_summary
from money_manager.web.routes.planning import expense_projects, forecast, payables, pending
from money_manager.web.routes.support import debts, documents, parent_support, receivables, sparagnat


def register_routes(app):
    app.register_blueprint(auth.bp)

    app.register_blueprint(dashboard.bp)
    app.register_blueprint(transactions.bp)
    app.register_blueprint(analysis.bp)
    app.register_blueprint(yearly_summary.bp)
    app.register_blueprint(net_explanation.bp)

    app.register_blueprint(accounts.bp)
    app.register_blueprint(currencies.bp)
    app.register_blueprint(internal_transfers.bp)

    app.register_blueprint(pending.bp)
    app.register_blueprint(forecast.bp)
    app.register_blueprint(payables.bp)
    app.register_blueprint(expense_projects.bp)

    app.register_blueprint(documents.bp)
    app.register_blueprint(sparagnat.bp)
    app.register_blueprint(debts.bp)
    app.register_blueprint(receivables.bp)
    app.register_blueprint(parent_support.bp)

    app.register_blueprint(investments.bp)
